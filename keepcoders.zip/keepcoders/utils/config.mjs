export const config = {
    apiKey: '66992561999ad6265d689c8b8c5b1765',
    language: 'es-ES'
}